package org.apache.spark.sql.catalyst

object ReflectionLock {

  val SparkReflectionLock = ScalaReflectionLock
}
