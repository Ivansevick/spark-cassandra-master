package com.datastax.spark.connector

/** Contains components for writing RDDs to Cassandra */
package object writer {

}
