package com.datastax.spark.connector

/** Useful stuff that didn't fit elsewhere. */
package object util {

}
